package studikasus;


public class UmurNegatifException extends Exception {
    public UmurNegatifException(String message) {
        super(message);
    }
}
