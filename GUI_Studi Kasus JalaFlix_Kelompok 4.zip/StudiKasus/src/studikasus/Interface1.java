package studikasus;

public interface Interface1 {
    public Film getPlaying(int i);
    public int totalFilm();
}
