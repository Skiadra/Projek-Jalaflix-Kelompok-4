package studikasus;


public class TahunTooOldException extends Exception {
    public TahunTooOldException(String message) {
        super(message);
    }
}
